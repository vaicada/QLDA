import AuthRoute from './AuthRoute.js'
import UserRoute from './UserRoute.js';
import NovelRoute from './NovelRoute.js'
import CommentRoute from './CommentRoute.js'
import AdminRoute from './AdminRoute.js'
import SavedRoute from './SavedRoute.js'
export {AuthRoute,UserRoute,NovelRoute,CommentRoute,AdminRoute,SavedRoute}