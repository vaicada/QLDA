export const ResponseData = (status,data)=>{
    return {
        status,
        data
    }
}

export const ResponseDetail = (status,details)=>{
    return {
        status,
        details
    }
}