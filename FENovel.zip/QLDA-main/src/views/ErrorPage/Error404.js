import React from 'react'
import Layout from '../'

function Error404() {
  return (
    <Layout><
  )
}

export default Error404