function Loading() {//component loading khi thực hiện thao tác (submit, handle)
  return (<i style={{"marginRight":'10px'}} className="bx bx-loader-alt bx-spin"></i> )
}
export default Loading