import React from 'react'
import './LoadingData.scss'

function LoadingData(props) {//component loading khi đang load dữ liệu
  return (
    <div className='d-flex LoadingData'>
<div className="loadingio-spinner-spinner-we6nz9vlz8"><div className="ldio-86jo8zq5pla">
<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
</div></div>
    </div>
  )
}

export default LoadingData